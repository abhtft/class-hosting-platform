// Starter backend (Node 22) for the class platform. Replace the routes with your own.
//
// The contract: export `handler(event, context)`. `event` is an API Gateway HTTP API (payload v2) event:
//   event.rawPath                  the path AFTER /api, e.g. "/health" (the site calls /api/health)
//   event.rawQueryString           text after "?"
//   event.requestContext.http.method
//   event.body, event.isBase64Encoded
// Return { statusCode, headers, body } where body is a string.
//
// Rules (see AGENTS.md): Node 22 built-ins only (nothing is npm-installed on the platform; bundle a package into one file if you
// really need it), at most 10 s per request (25 s while the class AI is on; longer work is a background job, see runJob below), secrets only in the portal's "Environment variables"
// (never in code or a .env file inside backend/).
//
// Run it on your computer with `npm run dev` (or `npm run dev -- --backend-only`).
import { AiError, ask } from './class_ai.mjs'; // the platform's helper for the class AI: two lines are all you need
import * as storage from './class_storage.mjs'; // the platform's helper for saving data (needs the teacher to switch class storage on)
import * as study from './study.mjs'; // EXAMPLE routes for the AI patterns (answer from books, feedback, an agent): read them, copy what you need, delete what you do not (see PATTERNS.md)

const json = (statusCode, data) => ({ statusCode, headers: { 'content-type': 'application/json' }, body: JSON.stringify(data) });

function readJson(event) {
  let raw = event.body || '';
  if (event.isBase64Encoded) raw = Buffer.from(raw, 'base64').toString('utf8');
  try {
    const data = raw ? JSON.parse(raw) : {};
    return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
  } catch {
    return {};
  }
}

/** A BACKGROUND JOB: work that takes longer than a web request (a chain of AI calls, a report). `job` is { id, name, payload }; whatever you return
 *  (JSON, at most 100 KB) is the result the page reads. Needs the teacher to switch jobs on; see AGENTS.md ("Work that takes longer"). */
async function runJob(job) {
  const payload = job.payload && typeof job.payload === 'object' && !Array.isArray(job.payload) ? job.payload : {};
  if (job.name === 'count') { // the page starts it with runJob('count', { n: 1000000 }) from src/api.ts
    let total = 0;
    for (let i = 0; i <= Number(payload.n ?? 10); i++) total += i;
    return { total };
  }
  throw new Error(`No job called ${job.name}.`);
}

export const handler = async (event) => {
  if (event.job) return runJob(event.job); // a background job, not a web request
  const { method } = event.requestContext.http;
  const path = event.rawPath;

  if (method === 'GET' && path === '/health') return json(200, { ok: true });

  if (method === 'GET' && path === '/hello') {
    const name = new URLSearchParams(event.rawQueryString || '').get('name') || 'world';
    return json(200, { message: `Hello, ${name}!` });
  }

  if (method === 'POST' && path === '/echo') return json(200, { youSent: readJson(event) });

  if (method === 'POST' && path === '/ask') {
    const prompt = String(readJson(event).prompt ?? '').trim();
    if (!prompt || prompt.length > 500) return json(400, { error: 'bad_request', message: 'Send a prompt of 1 to 500 characters.' });
    try {
      // THE class AI call. `ask` returns the answer text, or throws AiError with a friendly message.
      const answer = await ask(prompt, { system: 'You are a friendly helper for a school project. Answer in at most three sentences.', maxTokens: 200 });
      return json(200, { answer });
    } catch (error) {
      if (error instanceof AiError) return json(503, { error: error.kind, message: error.message });
      throw error;
    }
  }

  if (path === '/notes' && (method === 'GET' || method === 'POST')) {
    try {
      if (method === 'GET') return json(200, { notes: (await storage.items('notes')).map((row) => row.value).slice(-20) }); // ids start with the time: oldest first
      const text = String(readJson(event).text ?? '').trim();
      if (!text || text.length > 200) return json(400, { error: 'bad_request', message: 'Send a note of 1 to 200 characters.' });
      const note = { id: String(Date.now()).padStart(13, '0'), text };
      await storage.put('notes', note.id, note); // THE storage call: collection, id, any JSON
      return json(201, note);
    } catch (error) {
      if (error instanceof storage.StorageError) return json(503, { error: error.kind, message: error.message }); // not switched on, full, allowance used...
      throw error;
    }
  }

  const routed = await study.route(method, path, readJson(event)); // the example AI-pattern routes: /study, /feedback, /agent, /agent/approve
  if (routed) return json(...routed);

  return json(404, { error: 'not_found', message: 'No such route.' });
};
